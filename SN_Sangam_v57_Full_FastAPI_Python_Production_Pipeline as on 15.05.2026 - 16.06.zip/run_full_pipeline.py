import argparse
from app.services.full_pipeline import run_full_pipeline

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--series", default="EQ,FUTSTK,FUTIDX,FUTCOM")
    p.add_argument("--limit", type=int, default=0)
    p.add_argument("--out-dir", default=None)
    p.add_argument("--strike-step", type=int, default=50)
    args = p.parse_args()
    print(run_full_pipeline(series_csv=args.series, limit=args.limit, out_dir=args.out_dir, strike_step=args.strike_step))
