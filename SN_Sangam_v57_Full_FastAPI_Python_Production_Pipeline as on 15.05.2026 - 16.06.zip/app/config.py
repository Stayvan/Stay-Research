from pathlib import Path
import os
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parents[1]
load_dotenv(BASE_DIR / ".env")

DB_HOST = os.getenv("DB_HOST", "127.0.0.1")
DB_PORT = int(os.getenv("DB_PORT", "3306"))
DB_DATABASE = os.getenv("DB_DATABASE", "stayvan_trade_app")
DB_USERNAME = os.getenv("DB_USERNAME", "root")
DB_PASSWORD = os.getenv("DB_PASSWORD", "")

OUTPUT_DIR = Path(os.getenv("SVAYAM_OUTPUT_DIR", str(BASE_DIR / "app" / "outputs")))

TIMEFRAMES = ["D", "4H", "1H", "15M", "5M"]
TRADE_TFS = ["15M", "5M"]
STRATEGIES = ["GATI", "OJAS", "AKRITI"]

TF_TABLES = {
    "D": "ohlc_candles_daily",
    "4H": "ohlc_candles_4hourly",
    "1H": "ohlc_candles_1hourly",
    "15M": "ohlc_candles_15min",
    "5M": "ohlc_candles_5min",
}
TF_SEC = {"D": 22500, "4H": 14400, "1H": 3600, "15M": 900, "5M": 300}

LOOKBACKS = {"D": 89, "4H": 144, "1H": 233, "15M": 377, "5M": 455}
GATI_ATR_MULT = {"D": 7.86, "4H": 8.72, "1H": 9.68, "15M": 10.75, "5M": 11.93}
AKRITI_FRACTAL = {"D": 23, "4H": 28, "1H": 33, "15M": 27, "5M": 42}
SEED_PCT = 10.0

# Waterfall
USE_RAT_DEFAULT = False
USE_GCR_DEFAULT = True
USE_SLOR_DEFAULT = True

# Futures / Equity
ENTRY_BUFFER = 0.001
SL_BUFFER = 0.005
EOR_LIMIT = 0.01
EQUITY_RISK_AMOUNT = 13594.0
EQUITY_LOT_VALUE_MIN = 270788.0
EQUITY_LOT_VALUE_MAX = 290363.0
FUTURES_SLOR_MIN = 9062.0
FUTURES_SLOR_MAX = 27188.0
FUTURES_MAX_LOTS = 3
FUTCOM_MAX_LOTS = 5

# Options
OPTIONS_ENTRY_BUFFER = 0.0025
OPTIONS_SL_BUFFER = 0.01
OPTIONS_EOR_LIMIT = 0.1618
OPTIONS_SLOR_MIN = 5437.0
OPTIONS_SLOR_MAX = 16313.0
OPTIONS_MAX_LOTS = 3

# RSI DIV
RSI_PERIOD = 14
RSI_OB = 70.0
RSI_OS = 30.0
RSI_RESET = 50.0

EXPIRY_ROLL_DAYS = int(os.getenv("SVAYAM_EXPIRY_ROLL_DAYS", "15"))
