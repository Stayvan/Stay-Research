from dataclasses import dataclass
from typing import Literal

PointType = Literal["HIGH", "LOW"]
MoveType = Literal["UP", "DOWN"]

@dataclass
class Point:
    index: int
    price: float
    type: PointType
