from fastapi import FastAPI, Query
from app.services.full_pipeline import run_full_pipeline

app = FastAPI(title="SN Sangam by Ayaan v57 Full Pipeline", version="v57")

@app.get("/")
def root():
    return {"status": "SN Sangam v57 FastAPI running"}

@app.post("/run/full")
def run_full(
    series_csv: str = Query("EQ,FUTSTK,FUTIDX,FUTCOM"),
    limit: int = Query(0),
    out_dir: str | None = Query(None),
    strike_step: int = Query(50),
):
    return run_full_pipeline(series_csv=series_csv, limit=limit, out_dir=out_dir, strike_step=strike_step)
