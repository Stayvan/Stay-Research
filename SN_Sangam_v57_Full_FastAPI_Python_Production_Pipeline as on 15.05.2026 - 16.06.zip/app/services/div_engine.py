from typing import Dict
import pandas as pd
from app import config
from app.services.math_utils import rsi_sma

def div_state_for_df(df: pd.DataFrame) -> Dict[str, bool]:
    """
    Persistent RSI extreme-cycle divergence:
    - Negative divergence starts after RSI >=70. Blocks BUY until RSI <=50 reset.
    - Positive divergence starts after RSI <=30. Blocks SELL until RSI >=50 reset.
    Anchor does not move until reset. This mirrors Pine v57 intent.
    """
    if df is None or df.empty or len(df) < config.RSI_PERIOD + 3:
        return {"neg": False, "pos": False}
    d = df.reset_index(drop=True).copy()
    d["rsi"] = rsi_sma(d["close"], config.RSI_PERIOD)

    neg_tracking = False
    pos_tracking = False
    neg_div = False
    pos_div = False
    anchor_price_high = anchor_rsi_high = None
    anchor_price_low = anchor_rsi_low = None

    for _, row in d.iterrows():
        rsi = float(row["rsi"])
        h = float(row["high"])
        l = float(row["low"])

        # Check active divergence before any new anchoring.
        if neg_tracking and anchor_price_high is not None and anchor_rsi_high is not None:
            if h > anchor_price_high and rsi < anchor_rsi_high:
                neg_div = True
        if pos_tracking and anchor_price_low is not None and anchor_rsi_low is not None:
            if l < anchor_price_low and rsi > anchor_rsi_low:
                pos_div = True

        # Reset only at 50-cross back.
        if neg_tracking and rsi <= config.RSI_RESET:
            neg_tracking = False
            neg_div = False
            anchor_price_high = anchor_rsi_high = None

        if pos_tracking and rsi >= config.RSI_RESET:
            pos_tracking = False
            pos_div = False
            anchor_price_low = anchor_rsi_low = None

        # Start new cycles only when not tracking.
        if not neg_tracking and rsi >= config.RSI_OB:
            neg_tracking = True
            neg_div = False
            anchor_price_high = h
            anchor_rsi_high = rsi

        if not pos_tracking and rsi <= config.RSI_OS:
            pos_tracking = True
            pos_div = False
            anchor_price_low = l
            anchor_rsi_low = rsi

    return {"neg": bool(neg_div), "pos": bool(pos_div)}

def div_pass_for_trade(raw_by_tf: Dict, trade_tf: str, core: str) -> bool:
    """
    Internal DIV waterfall:
    15M checks D -> 4H -> 1H -> 15M
    5M checks  D -> 4H -> 1H -> 5M
    Negative divergence blocks BUY/UP.
    Positive divergence blocks SELL/DOWN.
    """
    chain = ["D", "4H", "1H", trade_tf]
    c = str(core or "").upper()
    for tf in chain:
        st = raw_by_tf[tf].get("DIV_STATE", {"neg": False, "pos": False})
        if c == "UP" and st.get("neg"):
            return False
        if c == "DOWN" and st.get("pos"):
            return False
    return True
