import math
from app import config

def entry_price(daily_df, core: str, *, is_option: bool = False):
    if daily_df is None or daily_df.empty:
        return None
    last = daily_df.reset_index(drop=True).iloc[-1]
    c = str(core or "").upper()
    if is_option:
        # Options are buy-only; CE or PE both require option chart UP and buy trigger.
        return float(last["high"]) * (1.0 + config.OPTIONS_ENTRY_BUFFER)
    if c == "UP":
        return float(last["high"]) * (1.0 + config.ENTRY_BUFFER)
    if c == "DOWN":
        return float(last["low"]) * (1.0 - config.ENTRY_BUFFER)
    return None

def stoploss_from_anchor(anchor, core: str, *, is_option: bool = False):
    if anchor is None:
        return None
    if is_option:
        return float(anchor) * (1.0 - config.OPTIONS_SL_BUFFER)
    c = str(core or "").upper()
    if c == "UP":
        return float(anchor) * (1.0 - config.SL_BUFFER)
    if c == "DOWN":
        return float(anchor) * (1.0 + config.SL_BUFFER)
    return None

def equity_slor(entry, sl):
    if entry is None or sl is None: return {"ok": False, "qty": None, "lot_value": None, "risk": None}
    risk = abs(float(entry) - float(sl))
    if risk <= 0: return {"ok": False, "qty": None, "lot_value": None, "risk": risk}
    base_qty = math.floor(config.EQUITY_RISK_AMOUNT / risk)
    base_lot_value = base_qty * float(entry)
    if base_lot_value < config.EQUITY_LOT_VALUE_MIN:
        return {"ok": False, "qty": None, "lot_value": base_lot_value, "risk": risk}
    qty = base_qty
    if base_lot_value > config.EQUITY_LOT_VALUE_MAX:
        qty = math.floor(config.EQUITY_LOT_VALUE_MAX / float(entry))
    lot_value = qty * float(entry)
    return {"ok": qty >= 1, "qty": qty, "lot_value": lot_value, "risk": risk}

def fno_slor(entry, sl, lot_size, series: str):
    if entry is None or sl is None: return {"ok": False, "lots": None, "risk_per_lot": None, "risk": None}
    risk = abs(float(entry) - float(sl))
    risk_per_lot = risk * float(lot_size or 1)
    max_lots = config.FUTCOM_MAX_LOTS if str(series or "").upper().startswith("FUTCOM") else config.FUTURES_MAX_LOTS
    if risk_per_lot < config.FUTURES_SLOR_MIN or risk_per_lot > config.FUTURES_SLOR_MAX:
        return {"ok": False, "lots": None, "risk_per_lot": risk_per_lot, "risk": risk}
    lots = min(math.floor(config.FUTURES_SLOR_MAX / risk_per_lot), max_lots)
    return {"ok": lots >= 1, "lots": lots, "risk_per_lot": risk_per_lot, "risk": risk}

def option_slor(entry, sl, lot_size):
    if entry is None or sl is None: return {"ok": False, "lots": None, "risk_per_lot": None, "risk": None}
    risk = abs(float(entry) - float(sl))
    risk_per_lot = risk * float(lot_size or 1)
    if risk_per_lot < config.OPTIONS_SLOR_MIN or risk_per_lot > config.OPTIONS_SLOR_MAX:
        return {"ok": False, "lots": None, "risk_per_lot": risk_per_lot, "risk": risk}
    lots = min(math.floor(config.OPTIONS_SLOR_MAX / risk_per_lot), config.OPTIONS_MAX_LOTS)
    return {"ok": lots >= 1, "lots": lots, "risk_per_lot": risk_per_lot, "risk": risk}
