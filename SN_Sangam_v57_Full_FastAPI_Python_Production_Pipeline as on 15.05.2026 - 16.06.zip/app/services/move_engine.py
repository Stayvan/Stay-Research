from typing import List, Optional, Dict, Any
import pandas as pd
from app.models.types import Point
from app import config
from app.services.math_utils import atr_14

def apply_lookback(df: pd.DataFrame, lookback: int) -> pd.DataFrame:
    return df.tail(min(len(df), int(lookback))).reset_index(drop=True)

def seed_points(df: pd.DataFrame) -> List[Point]:
    seed_len = max(2, int(round(len(df) * config.SEED_PCT / 100.0)))
    seed = df.iloc[:seed_len]
    hi_idx = int(seed["high"].idxmax())
    lo_idx = int(seed["low"].idxmin())
    hi = float(df.loc[hi_idx, "high"])
    lo = float(df.loc[lo_idx, "low"])
    return [Point(hi_idx, hi, "HIGH"), Point(lo_idx, lo, "LOW")] if hi_idx < lo_idx else [Point(lo_idx, lo, "LOW"), Point(hi_idx, hi, "HIGH")]

def previous_point(points: List[Point], start_pos: int, point_type: str) -> Optional[Point]:
    for j in range(start_pos - 1, -1, -1):
        if points[j].type == point_type:
            return points[j]
    return None

def build_gati_points(data: pd.DataFrame, tf: str) -> List[Point]:
    df = data.copy().reset_index(drop=True)
    df["atr"] = atr_14(df)
    points = seed_points(df)
    current = points[-1]
    for i in range(current.index + 1, len(df)):
        h = float(df.loc[i, "high"]); l = float(df.loc[i, "low"]); a = df.loc[i, "atr"]
        if pd.isna(a): continue
        threshold = float(a) * config.GATI_ATR_MULT[tf]
        if current.type == "HIGH":
            if h > current.price:
                current = Point(i, h, "HIGH"); points[-1] = current
            elif current.price - l >= threshold:
                current = Point(i, l, "LOW"); points.append(current)
        else:
            if l < current.price:
                current = Point(i, l, "LOW"); points[-1] = current
            elif h - current.price >= threshold:
                current = Point(i, h, "HIGH"); points.append(current)
    return points

def is_bull_good(df, i):
    if i == 0: return False
    rng = float(df.loc[i, "high"] - df.loc[i, "low"])
    body = abs(float(df.loc[i, "close"] - df.loc[i, "open"]))
    return rng > 0 and (body / rng) >= 0.70 and df.loc[i, "close"] > df.loc[i - 1, "close"]

def is_bear_good(df, i):
    if i == 0: return False
    rng = float(df.loc[i, "high"] - df.loc[i, "low"])
    body = abs(float(df.loc[i, "close"] - df.loc[i, "open"]))
    return rng > 0 and (body / rng) >= 0.70 and df.loc[i, "close"] < df.loc[i - 1, "close"]

def build_ojas_points(data: pd.DataFrame, tf: str) -> List[Point]:
    df = data.copy().reset_index(drop=True)
    points = seed_points(df); current = points[-1]
    bull_streak, bear_streak = [], []
    for i in range(current.index + 1, len(df)):
        h = float(df.loc[i, "high"]); l = float(df.loc[i, "low"])
        if current.type == "HIGH" and h > current.price:
            current = Point(i, h, "HIGH"); points[-1] = current; bull_streak.clear(); bear_streak.clear()
        elif current.type == "LOW" and l < current.price:
            current = Point(i, l, "LOW"); points[-1] = current; bull_streak.clear(); bear_streak.clear()
        if is_bear_good(df, i):
            bear_streak.append(i); bull_streak.clear()
        elif is_bull_good(df, i):
            bull_streak.append(i); bear_streak.clear()
        else:
            bull_streak.clear(); bear_streak.clear()
        if current.type == "HIGH" and len(bear_streak) >= 3:
            last3 = bear_streak[-3:]; lo_idx = min(last3, key=lambda x: df.loc[x, "low"])
            current = Point(lo_idx, float(df.loc[lo_idx, "low"]), "LOW"); points.append(current); bull_streak.clear(); bear_streak.clear()
        elif current.type == "LOW" and len(bull_streak) >= 3:
            last3 = bull_streak[-3:]; hi_idx = max(last3, key=lambda x: df.loc[x, "high"])
            current = Point(hi_idx, float(df.loc[hi_idx, "high"]), "HIGH"); points.append(current); bull_streak.clear(); bear_streak.clear()
    return points

def add_or_update_point(points: List[Point], new_point: Point):
    if not points:
        points.append(new_point); return
    last = points[-1]
    if new_point.type == last.type:
        if new_point.type == "HIGH" and new_point.price > last.price: points[-1] = new_point
        elif new_point.type == "LOW" and new_point.price < last.price: points[-1] = new_point
    else:
        points.append(new_point)

def fallback_lookback_points(df):
    hi_idx = int(df["high"].idxmax()); lo_idx = int(df["low"].idxmin())
    hi = float(df.loc[hi_idx, "high"]); lo = float(df.loc[lo_idx, "low"])
    return [Point(hi_idx, hi, "HIGH"), Point(lo_idx, lo, "LOW")] if hi_idx < lo_idx else [Point(lo_idx, lo, "LOW"), Point(hi_idx, hi, "HIGH")]

def build_akriti_points(data: pd.DataFrame, tf: str) -> List[Point]:
    df = data.copy().reset_index(drop=True)
    f = config.AKRITI_FRACTAL[tf]
    points = seed_points(df)
    seed_len = max(2, int(round(len(df) * config.SEED_PCT / 100.0)))
    start = max(f, seed_len); end = len(df) - f
    if end <= start:
        return fallback_lookback_points(df)
    for i in range(start, end):
        window = df.iloc[i - f:i + f + 1]
        high_val = float(df.loc[i, "high"]); low_val = float(df.loc[i, "low"])
        is_high = high_val == float(window["high"].max())
        is_low = low_val == float(window["low"].min())
        if is_high and not is_low: add_or_update_point(points, Point(i, high_val, "HIGH"))
        elif is_low and not is_high: add_or_update_point(points, Point(i, low_val, "LOW"))
    if len(points) < 2:
        return fallback_lookback_points(df)
    last = points[-1]; scan_start = last.index + 1
    if scan_start < len(df):
        latest_high = latest_low = None
        for p in reversed(points):
            if p.type == "HIGH" and latest_high is None: latest_high = p
            if p.type == "LOW" and latest_low is None: latest_low = p
            if latest_high and latest_low: break
        for i in range(scan_start, len(df)):
            h = float(df.loc[i, "high"]); l = float(df.loc[i, "low"])
            if last.type == "HIGH" and latest_low is not None and l < latest_low.price:
                add_or_update_point(points, Point(i, l, "LOW")); last = points[-1]
            elif last.type == "LOW" and latest_high is not None and h > latest_high.price:
                add_or_update_point(points, Point(i, h, "HIGH")); last = points[-1]
            if last.type == "HIGH" and h > last.price:
                points[-1] = Point(i, h, "HIGH"); last = points[-1]
            elif last.type == "LOW" and l < last.price:
                points[-1] = Point(i, l, "LOW"); last = points[-1]
    return points

def disha(points: List[Point], data: pd.DataFrame) -> str:
    df = data.reset_index(drop=True)
    if len(points) < 2: return "DOWN"
    p1, p2 = points[-1], points[-2]
    structure_move = "DOWN"
    if p1.type == "HIGH" and p2.type == "LOW":
        prev_high = previous_point(points, len(points) - 2, "HIGH")
        structure_move = "UP" if prev_high is None or p1.price > prev_high.price else "DOWN"
    elif p1.type == "LOW" and p2.type == "HIGH":
        prev_low = previous_point(points, len(points) - 2, "LOW")
        prev_high = previous_point(points, len(points) - 2, "HIGH")
        if prev_low is not None and prev_high is not None:
            structure_move = "UP" if p1.price > prev_low.price and p2.price > prev_high.price else "DOWN"
    last_high = last_low = None
    for p in reversed(points):
        if p.type == "HIGH" and last_high is None: last_high = p.price
        if p.type == "LOW" and last_low is None: last_low = p.price
        if last_high is not None and last_low is not None: break
    if last_high is None or last_low is None:
        return structure_move
    start = p1.index + 1
    if start < len(df):
        future = df.iloc[start:]
        if future["high"].max() > last_high: return "UP"
        if future["low"].min() < last_low: return "DOWN"
    return structure_move

def extreme_point_price(points: List[Point], point_type: str, want_lowest: bool):
    vals = [float(p.price) for p in (points or []) if p.type == point_type]
    if not vals: return None
    return min(vals) if want_lowest else max(vals)

def structure_sl_anchor(points: List[Point], core: str):
    c = str(core or "").upper()
    if c == "UP": return extreme_point_price(points, "LOW", True)
    if c == "DOWN": return extreme_point_price(points, "HIGH", False)
    return None

def evaluate_df(tf: str, tf_df: pd.DataFrame) -> Dict[str, Any]:
    data = apply_lookback(tf_df, config.LOOKBACKS[tf]).reset_index(drop=True)
    gati = build_gati_points(data, tf); ojas = build_ojas_points(data, tf); akriti = build_akriti_points(data, tf)
    out = {"DATA": data}
    for name, points in [("GATI", gati), ("OJAS", ojas), ("AKRITI", akriti)]:
        mv = disha(points, data)
        out[name] = {
            "points": points,
            "move": mv,
            "sl_buy_anchor": structure_sl_anchor(points, "UP"),
            "sl_sell_anchor": structure_sl_anchor(points, "DOWN"),
        }
    return out
