import pandas as pd
from app.services.math_utils import atr_14

def gcr_check(df: pd.DataFrame, core: str) -> bool:
    # v44 GCR style: broad good-candle/structure confirmation.
    if df is None or len(df) < 4:
        return False
    d = df.reset_index(drop=True)
    c0, c1, c2 = d.iloc[-1], d.iloc[-2], d.iloc[-3]

    def rng(c): return float(c["high"] - c["low"])
    def body(c): return abs(float(c["close"] - c["open"]))
    def small_body(c): return rng(c) > 0 and body(c) / rng(c) <= 0.30
    if rng(c0) <= 0:
        return False
    upper = float(c0["high"] - max(c0["open"], c0["close"]))
    lower = float(min(c0["open"], c0["close"]) - c0["low"])
    atr_val = atr_14(d).iloc[-1]
    long_candle = (not pd.isna(atr_val)) and rng(c0) >= float(atr_val) * 0.80
    bull_long = long_candle and c0["close"] > c0["open"]
    bear_long = long_candle and c0["close"] < c0["open"]
    bull_engulf = c0["close"] > c0["open"] and c1["close"] < c1["open"] and c0["close"] > c1["open"] and c0["open"] < c1["close"]
    bear_engulf = c0["close"] < c0["open"] and c1["close"] > c1["open"] and c0["open"] > c1["close"] and c0["close"] < c1["open"]
    bull_hammer = lower >= body(c0) * 2 and upper <= body(c0)
    bear_shooting = upper >= body(c0) * 2 and lower <= body(c0)
    bull_marubozu = c0["close"] > c0["open"] and upper <= rng(c0)*0.1 and lower <= rng(c0)*0.1
    bear_marubozu = c0["close"] < c0["open"] and upper <= rng(c0)*0.1 and lower <= rng(c0)*0.1
    bull_breakout = c0["close"] > c1["high"]
    bear_breakdown = c0["close"] < c1["low"]
    bull_higher_low = c0["low"] > c1["low"] and c0["close"] > c1["close"]
    bear_lower_high = c0["high"] < c1["high"] and c0["close"] < c1["close"]
    midpoint = (float(c0["high"]) + float(c0["low"])) / 2
    bull_range_expansion = rng(c0) > rng(c1) and c0["close"] > midpoint
    bear_range_expansion = rng(c0) > rng(c1) and c0["close"] < midpoint
    bull = any([bull_long, bull_engulf, bull_hammer, bull_marubozu, bull_breakout, bull_higher_low, bull_range_expansion])
    bear = any([bear_long, bear_engulf, bear_shooting, bear_marubozu, bear_breakdown, bear_lower_high, bear_range_expansion])
    c = str(core or "").upper()
    return bool(bull if c == "UP" else bear if c == "DOWN" else False)
