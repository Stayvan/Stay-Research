import pandas as pd
from sqlalchemy import text
from app import config

def normalize_ohlc_df(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or df.empty:
        return pd.DataFrame(columns=["time", "open", "high", "low", "close", "volume"])
    out = df.copy()
    out.columns = [str(c).strip().lower() for c in out.columns]
    if "candle_time" in out.columns and "time" not in out.columns:
        out = out.rename(columns={"candle_time": "time"})
    if "time" in out.columns:
        out["time"] = pd.to_datetime(out["time"], errors="coerce")
    for col in ["open", "high", "low", "close"]:
        out[col] = pd.to_numeric(out.get(col), errors="coerce")
    if "volume" not in out.columns:
        out["volume"] = 0
    else:
        out["volume"] = pd.to_numeric(out["volume"], errors="coerce").fillna(0)
    return out.dropna(subset=["time", "open", "high", "low", "close"]).sort_values("time").reset_index(drop=True)

def read_ohlc_for_iid(conn, iid: int, tf: str, limit: int | None = None) -> pd.DataFrame:
    table = config.TF_TABLES[tf]
    lim = int(limit or config.LOOKBACKS[tf])
    rows = conn.execute(text(f"""
        SELECT candle_time AS time, `open`, high, low, `close`,
               COALESCE(volume, 0) AS volume
        FROM {table}
        WHERE exchange_instrument_id = :iid
        ORDER BY candle_time DESC
        LIMIT :lim
    """), {"iid": int(iid), "lim": lim}).mappings().all()
    if not rows:
        return normalize_ohlc_df(pd.DataFrame())
    return normalize_ohlc_df(pd.DataFrame([dict(r) for r in rows]).iloc[::-1].reset_index(drop=True))

def select_instruments(conn, series_csv: str = "EQ,FUTSTK,FUTIDX,FUTCOM", limit: int = 0):
    series = [x.strip().upper() for x in str(series_csv).split(",") if x.strip()]
    placeholders = ", ".join([f":s{i}" for i in range(len(series))])
    params = {f"s{i}": s for i, s in enumerate(series)}
    limit_sql = " LIMIT :lim" if int(limit or 0) > 0 else ""
    if limit_sql:
        params["lim"] = int(limit)
    rows = conn.execute(text(f"""
        SELECT exchange_instrument_id, name, name_with_series, UPPER(TRIM(series)) AS series,
               contract_expiration, lot_size, multiplier, strike_price, option_type
        FROM instrument_masters
        WHERE UPPER(TRIM(series)) IN ({placeholders})
          AND exchange_instrument_id IS NOT NULL
        ORDER BY series, name, contract_expiration
        {limit_sql}
    """), params).mappings().all()
    return [dict(r) for r in rows]
