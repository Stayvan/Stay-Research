import math
from sqlalchemy import text
from app.services.expiry_engine import select_monthly_expiry
from app.services.candle_loader import read_ohlc_for_iid
from app.services.move_engine import evaluate_df
from app.services.div_engine import div_state_for_df, div_pass_for_trade
from app.services.gcr_engine import gcr_check
from app.services.eor_engine import eor_check
from app.services.slor_engine import entry_price, stoploss_from_anchor, option_slor
from app import config

def choose_option_type(futures_action: str) -> str:
    return "CE" if str(futures_action).upper() == "BUY" else "PE"

def nearest_strike(price: float, step: int = 50) -> int:
    return int(round(float(price) / step) * step)

def build_option_symbol(symbol: str, expiry, option_type: str, strike: int) -> str:
    yy = str(expiry.year)[-2:]
    mm = str(expiry.month).zfill(2)
    dd = str(expiry.day).zfill(2)
    t = "C" if option_type.upper().startswith("C") else "P"
    return f"{symbol}{yy}{mm}{dd}{t}{int(strike)}"

def find_option_instrument(conn, underlying: str, option_type: str, strike: int, expiry):
    # Best effort lookup. Adjust WHERE columns if your DB names differ.
    rows = conn.execute(text("""
        SELECT exchange_instrument_id, name, name_with_series, series, contract_expiration,
               lot_size, multiplier, strike_price, option_type
        FROM instrument_masters
        WHERE UPPER(name) = :sym
          AND DATE(contract_expiration) = :exp
          AND ROUND(strike_price, 0) = :strike
          AND UPPER(option_type) IN (:ot1, :ot2)
        LIMIT 1
    """), {
        "sym": str(underlying).upper(),
        "exp": expiry.isoformat(),
        "strike": int(strike),
        "ot1": option_type.upper(),
        "ot2": "CE" if option_type.upper().startswith("C") else "PE"
    }).mappings().all()
    return dict(rows[0]) if rows else None

def evaluate_option_chart(conn, opt_inst: dict, strategy: str, trade_tf: str):
    raw = {}; data = {}
    for tf in config.TIMEFRAMES:
        df = read_ohlc_for_iid(conn, int(opt_inst["exchange_instrument_id"]), tf, config.LOOKBACKS[tf])
        data[tf] = df
        raw[tf] = evaluate_df(tf, df)
        raw[tf]["DIV_STATE"] = div_state_for_df(raw[tf]["DATA"])

    core = "UP"  # options are buy-only
    if raw[trade_tf][strategy]["move"] != "UP":
        return {"result": "TFAT"}
    if not div_pass_for_trade(raw, trade_tf, core):
        return {"result": "DIV"}
    if not gcr_check(data["D"], core):
        return {"result": "GCR"}
    ep = entry_price(data["D"], core, is_option=True)
    close_price = float(data[trade_tf].reset_index(drop=True).iloc[-1]["close"])
    if not eor_check(ep, close_price, is_option=True):
        return {"result": "EOR"}
    anchor = raw[trade_tf][strategy]["sl_buy_anchor"]
    sl = stoploss_from_anchor(anchor, core, is_option=True)
    lot_size = float(opt_inst.get("lot_size") or opt_inst.get("multiplier") or 1)
    slor = option_slor(ep, sl, lot_size)
    if not slor["ok"]:
        return {"result": "SLOR"}
    sl_pct = abs(ep - sl) / ep * 100 if ep else None
    return {
        "result": "BUY", "action": "BUY", "entry": ep, "sl": sl, "sl_pct": sl_pct,
        "qty_lots": slor.get("lots"), "lot_size": lot_size,
        "stoploss_amount": slor.get("risk_per_lot"),
        "lot_value": ep * lot_size if ep else None
    }
