import datetime as dt
import calendar
from app import config

def last_tuesday(year: int, month: int) -> dt.date:
    cal = calendar.monthcalendar(year, month)
    week = cal[-1]
    if week[calendar.TUESDAY] == 0:
        week = cal[-2]
    return dt.date(year, month, week[calendar.TUESDAY])

def select_monthly_expiry(as_of: dt.date | None = None) -> dt.date:
    as_of = as_of or dt.date.today()
    cur = last_tuesday(as_of.year, as_of.month)
    if (cur - as_of).days >= config.EXPIRY_ROLL_DAYS:
        return cur
    if as_of.month == 12:
        return last_tuesday(as_of.year + 1, 1)
    return last_tuesday(as_of.year, as_of.month + 1)
