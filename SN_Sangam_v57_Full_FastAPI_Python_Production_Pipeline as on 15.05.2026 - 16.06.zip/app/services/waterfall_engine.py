from typing import Dict, Any
from app import config
from app.services.gcr_engine import gcr_check
from app.services.eor_engine import eor_check
from app.services.div_engine import div_pass_for_trade
from app.services.slor_engine import entry_price, stoploss_from_anchor, equity_slor, fno_slor

def rat_pass(_daily_df, _core: str) -> bool:
    # RAT currently OFF. Keep pass true.
    return True

def final_row_eval(raw: Dict[str, Any], data: Dict[str, Any], strat: str, trade_tf: str, series: str, lot_size: float):
    d = raw["D"][strat]["move"]; h4 = raw["4H"][strat]["move"]; h1 = raw["1H"][strat]["move"]
    m15 = raw["15M"][strat]["move"]; m5 = raw["5M"][strat]["move"]
    if not (d == h4 == h1):
        return {"result": "HTFAFM"}
    core = d
    if trade_tf == "15M" and m15 != core:
        return {"result": "TFAT", "core": core}
    if trade_tf == "5M" and m5 != core:
        return {"result": "TFAT", "core": core}
    if not rat_pass(data["D"], core):
        return {"result": "RAT", "core": core}
    if not div_pass_for_trade(raw, trade_tf, core):
        return {"result": "DIV", "core": core}
    if not gcr_check(data["D"], core):
        return {"result": "GCR", "core": core}
    ep = entry_price(data["D"], core)
    close_price = float(data[trade_tf].reset_index(drop=True).iloc[-1]["close"])
    if not eor_check(ep, close_price):
        return {"result": "EOR", "core": core}
    anchor = raw[trade_tf][strat]["sl_buy_anchor"] if core == "UP" else raw[trade_tf][strat]["sl_sell_anchor"]
    sl = stoploss_from_anchor(anchor, core)
    series_u = str(series or "EQ").upper()
    if series_u == "EQ":
        slor = equity_slor(ep, sl)
        ok = slor["ok"]; qty_lots = slor.get("qty"); lot_value = slor.get("lot_value")
    else:
        slor = fno_slor(ep, sl, lot_size, series_u)
        ok = slor["ok"]; qty_lots = slor.get("lots"); lot_value = float(ep) * float(lot_size or 1) if ep is not None else None
    if not ok:
        return {"result": "SLOR", "core": core, "raw_entry": ep, "raw_sl": sl, "raw_qty_lots": qty_lots, "raw_lot_value": lot_value}
    action = "BUY" if core == "UP" else "SELL"
    sl_pct = abs(float(ep)-float(sl))/abs(float(ep))*100 if ep else None
    return {"result": action, "core": core, "action": action, "entry": ep, "sl": sl, "sl_pct": sl_pct, "qty_lots": qty_lots, "lot_value": lot_value}
