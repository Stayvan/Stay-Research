from app import config

def eor_check(entry: float | None, close_price: float | None, *, is_option: bool = False) -> bool:
    if entry is None or close_price is None or entry <= 0:
        return False
    limit = config.OPTIONS_EOR_LIMIT if is_option else config.EOR_LIMIT
    return abs(float(close_price) - float(entry)) / float(entry) <= limit
