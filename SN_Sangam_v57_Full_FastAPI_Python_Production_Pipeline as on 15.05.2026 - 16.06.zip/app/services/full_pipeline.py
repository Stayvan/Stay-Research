import datetime as dt
from pathlib import Path
from app import config
from app.db import get_engine
from app.services.candle_loader import select_instruments, read_ohlc_for_iid
from app.services.move_engine import evaluate_df
from app.services.div_engine import div_state_for_df
from app.services.waterfall_engine import final_row_eval
from app.services.expiry_engine import select_monthly_expiry
from app.services.option_engine import choose_option_type, nearest_strike, find_option_instrument, build_option_symbol, evaluate_option_chart
from app.services.exporter import write_all_outputs

def _effective_lot_size(inst):
    ls = inst.get("lot_size")
    mult = inst.get("multiplier")
    try: ls = float(ls) if ls is not None else None
    except Exception: ls = None
    try: mult = float(mult) if mult is not None else None
    except Exception: mult = None
    if ls is None and mult is None: return 1.0
    if ls is None: return mult
    if mult is None: return ls
    return max(ls, mult)

def _sl_amount(action, entry, sl, qty_or_lot):
    if entry is None or sl is None or qty_or_lot is None: return None
    if str(action).upper() == "BUY":
        return (float(entry) - float(sl)) * float(qty_or_lot)
    return (float(sl) - float(entry)) * float(qty_or_lot)

def run_full_pipeline(series_csv="EQ,FUTSTK,FUTIDX,FUTCOM", limit=0, out_dir=None, strike_step=50):
    out_dir = Path(out_dir or config.OUTPUT_DIR)
    db = get_engine()
    vairagya_rows = []
    futures_rows = []
    option_rows = []
    parikshita_rows = []

    with db.connect() as conn:
        instruments = select_instruments(conn, series_csv=series_csv, limit=int(limit or 0))
        for inst in instruments:
            iid = int(inst["exchange_instrument_id"])
            series = str(inst.get("series") or "").upper()
            symbol = inst.get("name_with_series") or inst.get("name") or str(iid)
            base_symbol = inst.get("name") or symbol
            lot_size = _effective_lot_size(inst)
            raw = {}; data = {}; missing = False
            for tf in config.TIMEFRAMES:
                df = read_ohlc_for_iid(conn, iid, tf, config.LOOKBACKS[tf])
                if len(df) < 2:
                    missing = True
                    break
                data[tf] = df
                raw[tf] = evaluate_df(tf, df)
                raw[tf]["DIV_STATE"] = div_state_for_df(raw[tf]["DATA"])
            if missing:
                continue
            for strat in config.STRATEGIES:
                for trade_tf in config.TRADE_TFS:
                    ev = final_row_eval(raw, data, strat, trade_tf, series, lot_size)
                    action = ev.get("result")
                    entry = ev.get("entry"); sl = ev.get("sl"); qty_lots = ev.get("qty_lots"); lot_value = ev.get("lot_value")
                    row = {
                        "Sub_strategy": strat.title(),
                        "Symbol": symbol,
                        "Series": series,
                        "Contract_expiration": inst.get("contract_expiration"),
                        "Lot_size": lot_size,
                        "Trade_tf": trade_tf,
                        "Action": action,
                        "Entry": round(entry, 1) if entry is not None else None,
                        "SL": round(sl, 1) if sl is not None else None,
                        "Qty_Lots": qty_lots,
                        "Lot_value": round(lot_value, 1) if lot_value is not None else None,
                    }
                    vairagya_rows.append(row)

                    if action in ("BUY", "SELL"):
                        # Futures/cash final candidate
                        futures_rows.append(row)
                        sl_amt = _sl_amount(action, entry, sl, qty_lots if series == "EQ" else lot_size)
                        parikshita_rows.append({
                            "Sub_strategy": strat.title(),
                            "Symbol": symbol,
                            "Instrument": series,
                            "Expiry_date": inst.get("contract_expiration"),
                            "Option_type": None,
                            "Strike_price": None,
                            "Trade_time_frame": trade_tf,
                            "Action": action,
                            "Entry": round(entry, 1) if entry else None,
                            "Stoploss": round(sl, 1) if sl else None,
                            "Qty": qty_lots,
                            "Lot_size": lot_size,
                            "Stoploss_amount": round(sl_amt, 1) if sl_amt is not None else None,
                            "Lot_value": round(lot_value, 1) if lot_value is not None else None,
                        })

                    elif action == "SLOR" and series.startswith("FUT"):
                        # Try options substitute for futures SLOR.
                        opt_type = choose_option_type(ev.get("core") == "UP" and "BUY" or "SELL")
                        expiry = select_monthly_expiry(dt.date.today())
                        under_close = float(data["D"].reset_index(drop=True).iloc[-1]["close"])
                        strike = nearest_strike(under_close, strike_step)
                        opt_inst = find_option_instrument(conn, str(base_symbol).upper(), opt_type, strike, expiry)
                        opt_symbol = build_option_symbol(str(base_symbol).upper(), strike, opt_type, expiry) if False else build_option_symbol(str(base_symbol).upper(), strike, opt_type, expiry)
                        if opt_inst:
                            opt_eval = evaluate_option_chart(conn, opt_inst, strat, trade_tf)
                            opt_symbol = opt_inst.get("name_with_series") or opt_symbol
                            if opt_eval.get("result") == "BUY":
                                sl_amt = opt_eval.get("stoploss_amount")
                                opt_row = {
                                    "Sub_strategy": strat.title(),
                                    "Underlying_symbol": base_symbol,
                                    "Option_symbol": opt_symbol,
                                    "Expiry_date": expiry.isoformat(),
                                    "Option_type": opt_type,
                                    "Strike_price": strike,
                                    "Trade_time_frame": trade_tf,
                                    "Action": "BUY",
                                    "Entry": round(opt_eval.get("entry"), 1),
                                    "Stoploss": round(opt_eval.get("sl"), 1),
                                    "Qty": opt_eval.get("qty_lots"),
                                    "Lot_size": opt_eval.get("lot_size"),
                                    "Stoploss_amount": round(sl_amt, 1) if sl_amt is not None else None,
                                    "Lot_value": round(opt_eval.get("lot_value"), 1) if opt_eval.get("lot_value") is not None else None,
                                }
                                option_rows.append(opt_row)
                                parikshita_rows.append({
                                    "Sub_strategy": strat.title(),
                                    "Symbol": opt_symbol,
                                    "Instrument": "OPTIONS",
                                    "Expiry_date": expiry.isoformat(),
                                    "Option_type": opt_type,
                                    "Strike_price": strike,
                                    "Trade_time_frame": trade_tf,
                                    "Action": "BUY",
                                    "Entry": opt_row["Entry"],
                                    "Stoploss": opt_row["Stoploss"],
                                    "Qty": opt_row["Qty"],
                                    "Lot_size": opt_row["Lot_size"],
                                    "Stoploss_amount": opt_row["Stoploss_amount"],
                                    "Lot_value": opt_row["Lot_value"],
                                })
    paths = write_all_outputs(out_dir, vairagya_rows, futures_rows, option_rows, parikshita_rows)
    return {"status": "ok", "rows": {"vairagya": len(vairagya_rows), "futures": len(futures_rows), "options": len(option_rows), "parikshita": len(parikshita_rows)}, "files": paths}
