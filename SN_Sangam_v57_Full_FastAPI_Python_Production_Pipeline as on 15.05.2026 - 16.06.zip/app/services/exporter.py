from pathlib import Path
import pandas as pd
from app import config

VAIRAGYA_COLUMNS = ["Sub_strategy","Symbol","Series","Contract_expiration","Lot_size","Trade_tf","Action","Entry","SL","Qty_Lots","Lot_value"]
FUTURES_COLUMNS = VAIRAGYA_COLUMNS
OPTIONS_COLUMNS = ["Sub_strategy","Underlying_symbol","Option_symbol","Expiry_date","Option_type","Strike_price","Trade_time_frame","Action","Entry","Stoploss","Qty","Lot_size","Stoploss_amount","Lot_value"]
PARIKSHITA_COLUMNS = ["Sub_strategy","Symbol","Instrument","Expiry_date","Option_type","Strike_price","Trade_time_frame","Action","Entry","Stoploss","Qty","Lot_size","Stoploss_amount","Lot_value"]

def write_xlsx(path: Path, rows, columns):
    path.parent.mkdir(parents=True, exist_ok=True)
    df = pd.DataFrame(rows)
    for c in columns:
        if c not in df.columns:
            df[c] = None
    df = df[columns]
    df.to_excel(path, index=False)
    return str(path)

def write_all_outputs(out_dir: Path, vairagya, futures, options, parikshita):
    return {
        "vairagya": write_xlsx(out_dir / "file1_vairagya.xlsx", vairagya, VAIRAGYA_COLUMNS),
        "futures": write_xlsx(out_dir / "file2_futures.xlsx", futures, FUTURES_COLUMNS),
        "options": write_xlsx(out_dir / "file3_options.xlsx", options, OPTIONS_COLUMNS),
        "parikshita": write_xlsx(out_dir / "file4_parikshita.xlsx", parikshita, PARIKSHITA_COLUMNS),
    }
