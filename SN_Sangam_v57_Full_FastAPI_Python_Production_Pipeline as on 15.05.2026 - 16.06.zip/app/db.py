from sqlalchemy import create_engine
from app import config

def get_engine():
    pass_part = f":{config.DB_PASSWORD}" if config.DB_PASSWORD else ""
    url = f"mysql+pymysql://{config.DB_USERNAME}{pass_part}@{config.DB_HOST}:{config.DB_PORT}/{config.DB_DATABASE}"
    return create_engine(url, pool_pre_ping=True)
