# SN Sangam by Ayaan — Full FastAPI/Python v57 Pipeline

This package is **not a formatter**. It is a full pipeline:

```text
DB candles + instrument_masters
→ Pine v57 replica
→ File 1 Vairagya
→ File 2 Futures
→ File 3 Options
→ File 4 Parikshita
```

## Output files

Generated in `app/outputs/` by default:

1. `file1_vairagya.xlsx`
2. `file2_futures.xlsx`
3. `file3_options.xlsx`
4. `file4_parikshita.xlsx`

## File 1 — Vairagya columns

```text
Sub_strategy
Symbol
Series
Contract_expiration
Lot_size
Trade_tf
Action
Entry
SL
Qty_Lots
Lot_value
```

## File 4 — Parikshita columns

```text
Sub_strategy
Symbol
Instrument
Expiry_date
Option_type
Strike_price
Trade_time_frame
Action
Entry
Stoploss
Qty
Lot_size
Stoploss_amount
Lot_value
```

## Run from command line

```bash
pip install -r requirements.txt

python run_full_pipeline.py --series EQ,FUTSTK,FUTIDX,FUTCOM --limit 0 --out-dir app/outputs
```

Use `--limit 10` for a test run.

## Run as FastAPI

```bash
uvicorn app.main:app --reload
```

Then call:

```text
POST /run/full?series_csv=EQ,FUTSTK,FUTIDX,FUTCOM&limit=0
```

## Important locked logic

Waterfall:

```text
HTFAFM → TFAT → RAT → DIV → GCR → EOR → SLOR → BUY/SELL
```

DIV internal waterfall:

```text
15M trade: D → 4H → 1H → 15M
5M trade:  D → 4H → 1H → 5M
```

RAT is currently OFF and passes by default.

## Risk constants

Equity lot value:

```text
270788 → 290363
```

Futures SLOR:

```text
9062 → 27188
```

Options SLOR:

```text
5437 → 16313
```

## Notes

- This package expects your DB tables to exist with names:
  - `instrument_masters`
  - `ohlc_candles_daily`
  - `ohlc_candles_4hourly`
  - `ohlc_candles_1hourly`
  - `ohlc_candles_15min`
  - `ohlc_candles_5min`

- If your option instrument lookup columns differ, adjust `app/services/option_engine.py::find_option_instrument`.

- Pine v57 remains the logic source of truth.
